HJ-Join readme.txt


What is HJ-Join?

HJ-Join is a freeware utility for software distributors
(and people) who want to send and distribute large files.
With this program, others can automatically and easily 
join the split parts of these large files back together 
again. These split parts were split using HJSplit.

The reasons for HJSplit's (and HJ-Join's) existence are:
1) Large files can be more easily downloaded in smaller 
(split) chuncks than in one big piece.
2) Big files do not fit on floppies.
3) Of course there are many more reasons once you
start thinking about it :)


Included in this package are:

readme.txt
hj_join.txt
join16.exe (the 16 bit automatic joiner)
join32.exe (the 32 bit automatic joiner)


Program use:

The program will join all .001, .002, etc files which
reside in the same directory. These numbered files
are the output of the splitting program HJSplit.

As an example look at the following directory contents:
test.exe.001
test.exe.002
test.exe.003
test.exe.004
monkey.txt.001
monkey.txt.002
join32.exe
abc1.zip
efg2.txt
hik.exe

after executing join32.exe in this directory it will look like:
test.exe.001
test.exe.002
test.exe.003
test.exe.004
test.exe              <<<
monkey.txt.001
monkey.txt.002
monkey.txt            <<<
join32.exe
abc1.zip
efg2.txt
hik.exe

All the split files it could find in that directory,
the program has joined into the two files 
test.exe and monkey.txt
The other files (abc1.zip, efg2.txt, hik.exe) are not affected.


Platforms:

tested for:
Windows 3.x
Windows 95
Windows NT 4.0


HJ-Split and HJ-Join homepage

http://www.freebyte.com/hjsplit.htm

Distribution

HJ-Join can be freely distributed and used.
The program executable file itself may never be changed
by any persons other than the author.


Author:

Henk Hagedoorn
hjh@usa.net
freeware@bigfoot.com
http://www.freebyte.com
